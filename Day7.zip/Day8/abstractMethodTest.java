package programs.Day8;

//It is not mandatory to have a abstract method in abstract class
abstract class Cars {
	void BMW() {
		
	}
}
public class abstractMethodTest {

}
